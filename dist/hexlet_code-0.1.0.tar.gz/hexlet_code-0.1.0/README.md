### Hexlet tests and linter status:
[![Actions Status](https://github.com/Grafin-qp/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/Grafin-qp/python-project-49/actions)

[![Maintainability](https://api.codeclimate.com/v1/badges/64ef792b6bb3faa462a1/maintainability)](https://codeclimate.com/github/Grafin-qp/python-project-49/maintainability)


link to asciinema file for even game: https://asciinema.org/a/EetRmQpuz24SzyApxyjaUP31m

link to asciinema file for calc game: https://asciinema.org/a/rxlnNkAPdmRDfqyzKwBVgDHoD

link to asciinema file for gcd game: https://asciinema.org/a/FYOmzm5e6D5Z4Z6Oz6q3XLi2a

link to asciinema file for progression game: https://asciinema.org/a/ReTvFCsMuHNvxR0arj44AtdXY

link to asciinema file for prime game: https://asciinema.org/a/YFRnSEJamyAunltcSSUVHpJJz
